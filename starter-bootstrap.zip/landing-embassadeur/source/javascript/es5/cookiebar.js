/* eslint-env browser, amd */
(function() {
    'use strict';
    var Cookies = require('js-cookie');
    var ccBar = document.querySelector('.cc-bar');

    if (Cookies && !Cookies.get('accepted_cookies') && ccBar) {
        ccBar.classList.add('display');
        document.body.classList.add('cc-bar-opened');
        document.querySelector('.btn-close-cc').addEventListener('click', function() {
            Cookies.set('accepted_cookies', 'true');
            ccBar.classList.remove('display');
            document.querySelector('body').classList.remove('cc-bar-opened');
        });
    }
})();
