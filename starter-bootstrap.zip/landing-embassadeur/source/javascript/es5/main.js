/* eslint-env browser, amd */
/* global jQuery global */

/* Bootstrap 4 require Tether depencency */
require('tether/dist/js/tether.js');
/* Tether needs to be global */
global.Tether = require('tether');

require('bootstrap/dist/js/bootstrap.js');
//require('bootstrap/js/dist/util.js');
//require('bootstrap/js/dist/modal.js');
//require('bootstrap/js/dist/carousel.js');

require('./bootstrap-collapse.js');
require('./cookiebar.js');
require('./contrast.js');
require('./fontsize.js');
require('./iframe.js');
require('./inline-svg.js');
require('./leaflet.js');
require('./masonry.js');
require('./menu.js');
require('./owlcarousel.js');
require('./progressbar.js');
require('./reading-time.js');
require('./scrollto.js');
require('./scroll-trigger.js');
require('./tab-to-accordion.js');
require('./youtube-modal.js');
require('./carousel-in-modal.js');

//require('./bootstrap-popover.js');
//require('./gmap.js');
//require('./ie10-viewport-bug-workaround.js');
//require('./object-fit.js');
