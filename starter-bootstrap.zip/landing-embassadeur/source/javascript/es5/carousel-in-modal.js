/* eslint-env browser */
(function() {
    'use strict';

    $('.more-pictures-carousel').owlCarousel({
        margin: 15,
        responsiveClass: true,
        dots: false,
        loop: true,
        navText: ['←', '→'],
        responsive: {
            0: {
                items: 1,
                nav: false
            },
            480: {
                items: 2,
                nav: false
            },
            768: {
                items: 3,
                nav: true
            },
            992: {
                items: 4,
                nav: true
            }
        }, 
        onInitialize: callbackModalCarousel
    }); 


    function callbackModalCarousel() {
        $('.more-pictures-item').click(function(e) {
            if ($('body').width() > 480) {
                e.preventDefault();
                var imageUrl = $(this).data('image');
                var divBlockVisu = $($(this).data('blockvisu'));

                $(this).addClass('selected-item');
                $('.more-pictures-item').removeClass('selected-item');
                divBlockVisu.attr('src', imageUrl);
            }
        });

        $('.prev-picture').click(function(e) {
            if ($('body').width() > 480) {
                e.preventDefault();
                var imageUrl = $('.more-pictures-item.selected-item').data('image');

                if ($('.more-pictures-item.selected-item').parent().parent().parent('.owl-item').prev().find('.more-pictures-item').length > 0) {
                    $('.more-pictures-item.selected-item').removeClass('selected-item').parent().parent().parent('.owl-item').prev().find('.more-pictures-item').addClass('selected-item');
                } else {
                    $('.more-pictures-item.selected-item').removeClass('selected-item');
                    $('.owl-item:not(.item)').last().find('.more-pictures-item').addClass('selected-item');
                }
                if (imageUrl) {
                    var divBlockVisu = $($('.more-pictures-item.selected-item').data('blockvisu'));

                    divBlockVisu.fadeOut('fast', function() {
                        divBlockVisu.attr('src', imageUrl);
                        divBlockVisu.fadeIn('fast');
                    });
                }
            }
        });

        $('.next-picture').click(function(e) {
            if ($('body').width() > 480) {
                e.preventDefault();
                var imageUrl = $('.more-pictures-item.selected-item').data('image');
                
                if ($('.more-pictures-item.selected-item').parent().parent().parent('.owl-item').next().find('.more-pictures-item').length > 0) {
                    $('.more-pictures-item.selected-item').removeClass('selected-item').parent().parent().parent('.owl-item').next().find('.more-pictures-item').addClass('selected-item');
                } else {
                    $('.more-pictures-item.selected-item').removeClass('selected-item');
                    $('.owl-item:not(.item)').first().find('.more-pictures-item').addClass('selected-item');
                }
                if (imageUrl) {
                    var divBlockVisu = $($('.more-pictures-item.selected-item').data('blockvisu'));

                    divBlockVisu.fadeOut('fast', function() {
                        divBlockVisu.attr('src', imageUrl);
                        divBlockVisu.fadeIn('fast');
                    });
                }
            }
        });
    }
})();
