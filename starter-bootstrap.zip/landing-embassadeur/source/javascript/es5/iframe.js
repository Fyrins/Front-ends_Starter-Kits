/* eslint-env browser */

require('iframe-resizer');

(function () {
    'use strict';

    $('.iframe-resize').iFrameResize();
})();
