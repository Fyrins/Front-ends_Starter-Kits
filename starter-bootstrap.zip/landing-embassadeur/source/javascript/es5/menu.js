/* eslint-env browser, amd */
(function($) {
    'use strict';

    var isTouch = false;
    //var navigation = $('.okayNav').okayNav();

    $('.sousmenu').parent('.nav-item').addClass('has-sub');

    if($('html').hasClass('touchevents')) {
        isTouch = true;
    }

    if(window.matchMedia('(min-width: 992px)').matches && (isTouch === true)) {
        $('.has-sub').on('touchstart', function(e) {
            var $this = $(this);
            if (!$this.hasClass('hover')) {
                e.preventDefault();
                $('.nav-item').removeClass('hover');
                $this.addClass('hover');
            }
        });

        $('.main').on('touchstart', function(e) {
            e.preventDefault();
            $('.nav-item').removeClass('hover');
        });
    } else {
        $('.has-sub').hover(
            function() {
                var $this = $(this);
                $('.nav-item').removeClass('hover');
                $this.addClass('hover');
            },
            function() {
                var $this = $(this);
                $('.nav-item').removeClass('hover');
                $this.removeClass('hover');
            }
        );
    }

    $('.navbar-toggler').on('touchstart, click', function(e) {
        e.preventDefault();
        var $this = $(this);
        $this.siblings('.collapse').toggleClass('show');
    });
})(jQuery);
