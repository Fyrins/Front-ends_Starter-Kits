/* eslint-env browser, amd */

(function($) {
    'use strict';

    var $window = $(window);

    function onScroll() {
        var scrolled = $window.scrollTop(),
            winHeight = $window.height();

        // Show
        $('.onScroll:not(.animated)').each(function() {
            var $this = $(this),
                offsetTop = $this.offset().top;

            if (scrolled + winHeight > offsetTop) {
                if ($this.data('timeout')) {
                    window.setTimeout(function() {
                        $this.addClass('animated ' + $this.data('animation'));
                    }, parseInt($this.data('timeout'), 10));
                } else {
                    $this.addClass('animated ' + $this.data('animation'));
                }
            }
        });
        // Hide
        $('.onScroll.animated').each(function() {
            var $this = $(this),
                offsetTop = $this.offset().top;
            if (scrolled + winHeight < offsetTop) {
                $(this).removeClass('animated');
            }
        });
    }


    $(document).ready(function() {
        $window.on('scroll', onScroll);
    });

})(jQuery);
