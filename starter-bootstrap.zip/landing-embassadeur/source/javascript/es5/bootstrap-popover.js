/* eslint-env browser, amd */

require('bootstrap/dist/js/bootstrap.js');

//require('bootstrap/dist/js/umd/tooltip.js');
//require('bootstrap/dist/js/umd/popover.js');

(function($) {
    'use strict';

    $('a[data-toggle="popover"]').click(function(event){
        event.preventDefault();
    });
    
    $('[data-toggle="popover"]').popover();
})(jQuery);
