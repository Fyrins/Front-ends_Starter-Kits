/* eslint-env browser, amd */
var objectFitImages = require('object-fit-images/dist/ofi.common-js.js');

(function() {
    'use strict';

    var fitImages = document.querySelectorAll('img.object-fit');
    objectFitImages(fitImages);
})();
