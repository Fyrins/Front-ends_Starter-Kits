/* eslint-env browser, amd */
(function() {
    'use strict';
    function tabToAccordion() {
        var tabLink = $('.tab-accordion-link');

        tabLink.click(function(e) {
            var href = $(this).attr('href');
            e.preventDefault();

            tabLink.removeClass('active');
            // Set both link to active (tab + accordion)
            $('.tab-accordion-link[href="' + href + '"]').toggleClass('active');

            //Set content to active
            $('.tab-pane').removeClass('in active');
            $(href).addClass('in active');
        });
    }

    $(document).ready(function() {
        tabToAccordion();
    });
})();
