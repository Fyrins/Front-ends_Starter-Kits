/* eslint-env browser, amd */
(function() {
    'use strict';

    var progressDiv = document.getElementById('progression');

    function setProgression() {
        var screenHeight = screen.height,
            visibleHeight = document.body.clientHeight,
            screenScrolled = window.pageYOffset,
            pctScrolled = Math.round(screenScrolled / (visibleHeight - screenHeight) * 100);
        
        progressDiv.setAttribute('style', 'width:' + pctScrolled + '%');
    }

    if(progressDiv) {
        window.addEventListener('scroll', function(){
            setProgression();
        });
        window.addEventListener('resize', function(){
            setProgression();
        });
    }
})();
