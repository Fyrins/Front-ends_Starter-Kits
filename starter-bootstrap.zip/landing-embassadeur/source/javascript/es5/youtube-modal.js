/* eslint-env browser, amd */

(function ($) {
    'use strict';

    $('#youtubeModal').on('show.bs.modal', function (event) {
        var youtubeLink = $(event.relatedTarget).data('youtube-id'),
            modal = $(this);
        modal.find('.embed-responsive-item').attr('src', 'https://www.youtube.com/embed/' + youtubeLink);
    });
})(jQuery);