/* eslint-env browser, amd */

(function() {
    'use strict';

    function getText(e) {
        var ret = '';
        var length = e.childNodes.length;

        for (var i = 0; i < length; i++) {
            var node = e.childNodes[i];
            if(node.nodeType != 8) {
                ret += node.nodeType != 1 ? node.nodeValue : getText(node);
            }
        }
        return ret;
    }

    var eta = document.querySelector('.eta');

    if(eta){ // Regarde si la balise eta existe
        var wordCount = getText(eta).split(/[^\s]+/g).length,
            time = Math.round(wordCount / 200);

        document.querySelector('.progress p span').innerHTML = time;
    }
})();
