/* eslint-env browser, amd */

require('bootstrap-datepicker/dist/js/bootstrap-datepicker.js');
require('bootstrap-datepicker/dist/locales/bootstrap-datepicker.fr.min.js');

(function($) {
    'use strict';

    $('.datepicker').datepicker({
        language: 'fr'
    });
})(jQuery);
