/* eslint-env browser, amd */
(function($) {
    'use strict';

    var Cookies = require('js-cookie');

    function switchContrast() {
        var contrastBtn = $('.a11y-contrast');
        var htmlTag = $('html');

        if (Cookies && Cookies.get('contrast')) {
            if (Cookies.get('contrast') == 'true') {
                htmlTag.addClass('contrast');
            }
        }

        contrastBtn.click(function(e) {
            e.preventDefault();
            var $this = $(this);
            var hasContrast;
            if ($this.hasClass('a11y-contrast--up')) {
                htmlTag.addClass('contrast');
                hasContrast = true;
            } else {
                htmlTag.removeClass('contrast');
                hasContrast = false;
            }
            Cookies.set('contrast', hasContrast);
        });
    }

    $(document).ready(function() {
        switchContrast();
    });
})(jQuery);
