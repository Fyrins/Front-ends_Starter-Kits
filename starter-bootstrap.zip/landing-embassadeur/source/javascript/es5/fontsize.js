/* eslint-env browser, amd */

(function($) {
    'use strict';

    var Cookies = require('js-cookie');

    function fontSize() {
        if (Cookies && Cookies.get('fontSize')) {
            $('html').css('font-size', Cookies.get('fontSize') + 'px');
        }
        var $fontBtn = $('.a11y-font');
        var htmlFontSize = $('html').css('font-size');
        $fontBtn.click(function(e) {
            e.preventDefault();
            var $this = $(this);
            if ($this.hasClass('a11y-font--up')) {
                htmlFontSize = Math.round(parseFloat(htmlFontSize) + 1);
                $('html').css('font-size', htmlFontSize + 'px');
            } else {
                htmlFontSize = Math.round(parseFloat(htmlFontSize) - 1);
                $('html').css('font-size', htmlFontSize + 'px');
            }
            Cookies.set('fontSize', htmlFontSize);
        });
    }

    $(document).ready(function() {
        fontSize();
    });
})(jQuery);
