/* eslint-env browser, amd */
/* global GMaps */

(function ($) {
    'use strict';

    $(document).ready(function () {
        if (window.GMaps) {
            var map = new GMaps({
                div: '#map',
                lat: 45.78181193296326,
                lng: 3.1366369128227234,
                zoomIn: 0,
                draggable: false,
                scrollwheel: false
            });
            map.addMarker({
                lat: 45.78181193296326,
                lng: 3.1366369128227234,
                title: 'Periscope',
                infoWindow: {
                    content: 'On est là !'
                }
            });
        }
    });
})(jQuery);