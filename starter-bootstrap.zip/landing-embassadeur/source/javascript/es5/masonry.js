/* eslint-env browser, amd */

//matchmedia is a polyfill needed for < IE11 
//http://caniuse.com/#search=matchMedia
//require('matchmedia-polyfill');

(function ($) {
    'use strict';
    var Masonry = require('masonry-layout');
    var imagesLoaded = require('imagesloaded');

    var grid = document.getElementById('masonry-grid');

    if (!grid) {
        return;
    }

    var masonryOptions = {
            itemSelector: '[class^=col-]',
            columnWidth: '.grid-sizer',
            isOriginLeft: true
        },
        masonryActived = false;

    function testMatchMedia() {
        var msnry = new Masonry(grid, masonryOptions);

        if (window.matchMedia('(max-width: 768px)').matches && (masonryActived === true)) {
            msnry.destroy();
            masonryActived = false;
        } else {
            imagesLoaded(grid, function () {
                msnry = new Masonry(grid, masonryOptions);
                masonryActived = true;
            });
        }
    }

    $(document).ready(function () {
        testMatchMedia();
        $(window).resize(testMatchMedia);
    });
})(jQuery);
