/* eslint-env browser, amd */

// Load Bootstrap Collapse plugin
require('bootstrap/dist/js/bootstrap.js');
//require('bootstrap/dist/js/umd/collapse.js');

// Load scrollTo script
var scrollTo = require('./scrollto.js');

(function($) {
    // +/- button next to panel title
    var $buttonTre = $('.panel-title .button-tre');

    $('.panel-title a').click(function(e) {
        e.preventDefault();
        var $this = $(this);
        // If current Button has is +/- button, use $this. Une $this.next is title is clicked
        var currentButton = $(this).hasClass('button-tre') ? $this : $this.next();
        var currentButtonHasLess = currentButton.hasClass('button-less');

        // Reset +/- button class to button-more
        $buttonTre.removeClass('button-less').addClass('button-more');

        // Toggle +/- button class
        currentButton.toggleClass('button-less', !currentButtonHasLess).toggleClass('button-more', currentButtonHasLess);

        //Scroll to panel title when panel content is open
        $('#accordion').on('shown.bs.collapse', function() {
            scrollTo($this);
        });
    });
})(jQuery);
