/* eslint-env browser, amd, node */

var scrollTo = function scrollTo(elt) {
    $('html, body').animate({
        scrollTop: elt.offset().top
    });

    return false;
};

module.exports = scrollTo;
