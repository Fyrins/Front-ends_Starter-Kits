/* eslint-env browser, amd */

(function() {
    'use strict';
    var L = require('leaflet');

    $(document).ready(function() {
        var myIcon = L.icon({
            iconUrl: 'images/marker.png',
            iconSize: [26, 38],
            iconAnchor: [0, 38]
        });
        var layer = L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token=pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpandmbXliNDBjZWd2M2x6bDk3c2ZtOTkifQ._QA7i5Mpkd_m30IGElHziw', {
            maxZoom: 18,
            attribution: 'Map data &copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors, ' +
                '<a href="http://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, ' +
                'Imagery © <a href="http://mapbox.com">Mapbox</a>',
            id: 'mapbox.light'
        });

        if($('#leaflet-map').length > 0){
            var contactMap = L.map('leaflet-map').setView([39.0247854, 125.7519995], 17);
            var marker = L.marker([39.0247854, 125.7519995], { icon: myIcon }).bindPopup('<h3>Nos locaux</h3><strong>NOODO</strong><br>8 rue Georges Besse <br>63100 Clermont-Ferrand').openPopup().addTo(contactMap);
            layer.addTo(contactMap);
        }
    });
})();
