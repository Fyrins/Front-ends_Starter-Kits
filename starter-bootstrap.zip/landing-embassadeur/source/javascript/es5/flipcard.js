/* eslint-env browser, amd */
(function($) {
    'use strict';
    $('.card').click(function() {
        $('.card.hover').removeClass('hover');
        $(this).toggleClass('hover');
    });

    $('.card-hover').click(function(e) {
        e.preventDefault();
        var urlFiche = $(this).attr('data-redirect');
        window.location.href = urlFiche;
    });
})(jQuery);
