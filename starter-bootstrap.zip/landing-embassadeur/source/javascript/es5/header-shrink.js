/* eslint-env browser, amd */
(function() {
    'use strict';

    function init() {
        window.addEventListener('scroll', function() {
            var distanceY = window.pageYOffset || document.documentElement.scrollTop,
                header = document.querySelector('header'),
                shrinkOn = header.offsetHeight;
            if (distanceY > shrinkOn) {
                header.classList.add('header--scroll');
            } else {
                if (header.classList.contains('header--scroll')) {
                    header.classList.remove('header--scroll');
                }
            }
        });
    }
    window.onload = init();
})();
