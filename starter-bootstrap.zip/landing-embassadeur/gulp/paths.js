/* eslint-env node, es6 */
'use strict';

exports.SRC = require('./paths-src.js');
exports.DST = require('./paths-dst.js');