/* eslint-env node, es6 */
'use strict';
const SRC = require('../paths.js').SRC;
const DST = require('../paths.js').DST;
const gulp = require('gulp');
var fileinclude = require('gulp-file-include');

gulp.task('build-html', () => {
    return gulp.src(`${SRC.DECOUPE_BASE}/*.html`)
        // HTML Minification
        //.pipe(minifyhtml({
        //    collapseWhitespace: true,
        //    minifyCSS: true,
        //    removeComments: true
        //}))
        .pipe(fileinclude({
            prefix: '@@',
            basepath: '@file'
        }))
        // Copy HTML files to public folder
        .pipe(gulp.dest(DST.DECOUPE_BASE));
});

gulp.task('watch-html', () => gulp.watch(`${SRC.DECOUPE_BASE}/*.html`, ['build-html']));
