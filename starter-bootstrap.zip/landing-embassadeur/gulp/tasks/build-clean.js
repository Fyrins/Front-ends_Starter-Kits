/* eslint-env node, es6 */
'use strict';
const DST = require('../paths.js').DST;
const gulp = require('gulp');
const del = require('del');

// Delete the content of the DST.DECOUPE_BASE folder (i.e. public/)
gulp.task('clean', () => del(`${DST.DECOUPE_BASE}/**/*`));