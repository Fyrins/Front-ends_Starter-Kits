/* eslint-env node, es6 */
'use strict';
const SRC = require('../paths.js').SRC;
const DST = require('../paths.js').DST;
const gulp = require('gulp');

const src = `${SRC.NODE_MODULE_PATH}/jquery/dist/jquery.min.*`;
const dst = DST.JAVASCRIPT;

gulp.task('build-jquery', () => gulp.src(src).pipe(gulp.dest(dst)));
