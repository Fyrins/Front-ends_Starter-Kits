/* eslint-env node, es6 */
'use strict';
const SRC = require('../paths.js').SRC;
const DST = require('../paths.js').DST;
const gulp = require('gulp');
const path = require('path');

const iconfont = require('gulp-iconfont');
const iconfontCss = require('gulp-iconfont-css');
const absoluteTargetSCSSPath = path.resolve(__dirname, '../../', `${SRC.DECOUPE_SASS}/modules/_icons.scss`);

// Create an icon based on the SVGs of the svgicons folder
gulp.task('build-icons', () => {
    return gulp.src(`${SRC.DECOUPE_SVGICONS}/*`)
        .pipe(iconfontCss({
            fontName: 'icons',
            targetPath: absoluteTargetSCSSPath,
            fontPath: '../fonts/icons/'
        }))
        .pipe(iconfont({
            fontName: 'icons',
            formats: ['ttf', 'eot', 'woff', 'woff2', 'svg'],
            normalize: true, // Apply same height to each svg
            timestamp: Math.round(Date.now() / 1000)
        }))
        .pipe(gulp.dest(`${DST.FONTS}/icons/`));
});

gulp.task('watch-icons', () => gulp.watch(`${SRC.DECOUPE_SVGICONS}/*`, ['build-icons', 'build-scss']));