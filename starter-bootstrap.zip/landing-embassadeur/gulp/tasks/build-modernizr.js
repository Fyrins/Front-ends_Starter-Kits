/* eslint-env node, es6 */
'use strict';
const SRC = require('../paths.js').SRC;
const DST = require('../paths.js').DST;
const gulp = require('gulp');
const uglify = require('gulp-uglify');
const sourcemaps = require('gulp-sourcemaps');
const modernizr = require('gulp-modernizr');

gulp.task('build-modernizr', () => {
    return gulp.src(`${SRC.DECOUPE_SASS}/**/*.scss`) // Parse SCSS files to look for CSS properties
        .pipe(modernizr(DST.FILENAME_MODERNIZR, {
            options: ['setClasses'],
            tests: ['touchevents']
        }))
        .pipe(sourcemaps.init())
        .pipe(uglify())
        .pipe(sourcemaps.write('./'))
        .pipe(gulp.dest(DST.JAVASCRIPT));
});
