/* eslint-env node, es6 */
'use strict';
const gulp = require('gulp');

gulp.task('default',   ['watch']);