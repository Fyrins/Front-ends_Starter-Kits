/* eslint-env node, es6 */
'use strict';
const path = require('path');
const SRC  = require('../paths.js').SRC;
const DST  = require('../paths.js').DST;
const gulp = require('gulp');
const pdf  = require('gulp-html-pdf');

const printConfig = {
    'format': 'A5',
    'border': {
        'top': '0.1cm',
        'right': '0.1cm',
        'bottom': '0.1cm',
        'left': '0.1cm'
    },
    'base': 'file:///' + path.resolve('./') + '/public/'
};

/* compile html files */
gulp.task('build-pdf', () => {
    return gulp.src(`${SRC.DECOUPE_BASE}/pdf.html`)
        .pipe(pdf(printConfig))
        .pipe(gulp.dest(DST.DECOUPE_PDF));
});

gulp.task('watch-pdf', () => gulp.watch(`${SRC.DECOUPE_BASE}/*.html`, ['build-pdf']));
