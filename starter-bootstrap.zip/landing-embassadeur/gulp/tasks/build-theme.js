/* eslint-env node, es6 */
'use strict';
const DST = require('../paths.js').DST;
const gulp = require('gulp');

/* compile html files */
gulp.task('build-theme', () => {
    return gulp.src([`${DST.DECOUPE_BASE}/**/*`, `!${DST.DECOUPE_BASE}/*.html`])
        .pipe(gulp.dest(`${DST.CMS_THEME_PATH}`)); 
});
