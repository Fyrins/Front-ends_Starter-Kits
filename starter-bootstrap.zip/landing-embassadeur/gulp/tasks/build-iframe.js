/* eslint-env node, es6 */
'use strict';
const SRC = require('../paths.js').SRC;
const DST = require('../paths.js').DST;
const gulp = require('gulp');

const src = `${SRC.NODE_MODULE_PATH}/iframe-resizer/js/iframeResizer.contentWindow.min.js`;
const dst = DST.JAVASCRIPT;

gulp.task('build-iframe', () => gulp.src(src).pipe(gulp.dest(dst)));
