/* eslint-env node, es6 */
'use strict';
const gulp = require('gulp');

gulp.task('build-all', [
    'build-html',
    'build-icons',
    'build-scss',
    'build-img',
    'build-fonts',
    'build-js',
    'build-jquery',
    'build-iframe',
    'build-modernizr'
]);