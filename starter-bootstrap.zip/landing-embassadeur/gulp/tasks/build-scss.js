/* eslint-env node, es6 */
'use strict';
const SRC = require('../paths.js').SRC;
const DST = require('../paths.js').DST;
const gulp = require('gulp');
const sass = require('gulp-sass');
const sourcemaps = require('gulp-sourcemaps');
const minifycss = require('gulp-cssnano');
const beep = require('beepbeep');
const util = require('gulp-util');

// Browsers version will specify brower specifix prefixes
const minifyConfig = {
    safe: true,
    zindex: false,
    autoprefixer: {
        add: true,
        browsers: [
            'Edge 12',
            'Chrome 55',
            'Firefox ESR',
            'Safari 9',
            'Android 4.4',
            'ie 10',
            'iOS 9'
        ]
    }
};

if (util.env.production) {
    minifyConfig.discardComments = {
        removeAll: true
    };
}

/* Compile scss files */
gulp.task('build-scss', () => {
    return gulp.src(`${SRC.DECOUPE_SASS}/**/*.scss`)
        .pipe(sourcemaps.init())
        .pipe(sass().on('error', sass.logError))
        .pipe(minifycss(minifyConfig))
        .pipe(sourcemaps.write('./'))
        .pipe(gulp.dest(DST.STYLES))
        .on('end', () => {
            beep();
        });
});

gulp.task('watch-scss', () => gulp.watch(`${SRC.DECOUPE_SASS}/**/*.scss`, ['build-scss']));
