/* eslint-env node, es6 */
'use strict';
const SRC = require('../paths.js').SRC;
const DST = require('../paths.js').DST;
const gulp = require('gulp');
const less = require('gulp-less');
const sourcemaps = require('gulp-sourcemaps');
const minifycss = require('gulp-cssnano');
const beep = require('beepbeep');
const util = require('gulp-util');

const minifyConfig = {
    safe: true,
    zindex: false,
    autoprefixer: {
        add: true,
        browsers: [
            'Edge 12',
            'Chrome 46',
            'Firefox ESR',
            'Safari 8',
            'Android 4.4',
            'ie 11',
            'iOS 8.1'
        ]
    }
};

if (util.env.production) {
    minifyConfig.discardComments = {
        removeAll: true
    };
}

/* Compile less files */
gulp.task('build-less', () => {
    return gulp.src(`${SRC.DECOUPE_LESS}/**/*.less`)
        .pipe(sourcemaps.init())
        .pipe(less())
        .pipe(minifycss(minifyConfig))
        .pipe(sourcemaps.write('./'))
        .pipe(gulp.dest(DST.STYLES))
        .on('end', () => {
            beep();
        });
});

gulp.task('watch-less', () => gulp.watch(`${SRC.DECOUPE_LESS}/**/*.less`, ['build-less']));