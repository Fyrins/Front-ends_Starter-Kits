/* eslint-env node, es6 */
'use strict';
const DST = require('../paths.js').DST;
const gulp = require('gulp');
const bs = require('browser-sync').create();

gulp.task('browser-sync', () => {
    bs.init([`${DST.DECOUPE_STYLES}/**/*.css`, `${DST.DECOUPE_BASE}/*.html`], {
        server: {
            baseDir: `${DST.DECOUPE_BASE}`
        }
    });
});