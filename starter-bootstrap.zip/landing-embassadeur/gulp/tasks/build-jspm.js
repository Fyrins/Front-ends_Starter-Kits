/* eslint-env node, es6 */
'use strict';
const SRC = require('../paths.js').SRC;
const DST = require('../paths.js').DST;
const gulp = require('gulp');
const gulp_jspm = require('gulp-jspm');
const sourcemaps = require('gulp-sourcemaps');
const path = require('path');

const entryPoints = [{
    main: `${SRC.DECOUPE_JS}/es6/main.js`,
    watch: [
        `${SRC.DECOUPE_JS}/**/*.js`,
        `!${SRC.DECOUPE_JS}/jspm_packages/**/*.js`
    ]
}];


entryPoints.forEach(data => {
    const filename = data.main;
    const watch = data.watch;
    const id = path.basename(data.main).replace('.js', '');
    const taskName = `build-es6-${id}`;

    gulp.task(taskName, () => {
        return gulp.src(filename)
            .pipe(sourcemaps.init())
            .pipe(gulp_jspm({
                //verbose: true,
                selfExecutingBundle: true
            }).on('error', error => {
                console.error(error.message); // eslint-disable-line no-console
            }))
            .pipe(sourcemaps.write('.'))
            .pipe(gulp.dest(`${DST.JAVASCRIPT}/${id}.build.js`));
    });

    gulp.task(`watch-es6-${id}`, () => gulp.watch(watch, [taskName]));
});