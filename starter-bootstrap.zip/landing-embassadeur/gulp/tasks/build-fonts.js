/* eslint-env node, es6 */
'use strict';
const SRC = require('../paths.js').SRC;
const DST = require('../paths.js').DST;
const gulp = require('gulp');

// Copy font files to public folder
gulp.task('build-fonts', () => gulp.src(`${SRC.DECOUPE_FONTS}/**/*`)
    .pipe(gulp.dest(DST.DECOUPE_FONTS)));