/* eslint-env node, es6 */
'use strict';
const gulp = require('gulp');

/* Watch these files for changes and run the task on update */
gulp.task('watch', ['watch-html', 'watch-icons', 'watch-scss', 'watch-img', 'watch-js']);

/* run the watch task when gulp is called without arguments */
gulp.task('default', ['watch']);