/* eslint-env node, es6 */
'use strict';

/*
    All paths are relative to the `gulpfile.js` file
*/

/* file names */
const FILENAME_MODERNIZR = `modernizr-custom.js`;

exports.FILENAME_MODERNIZR = FILENAME_MODERNIZR;

/* decoupe related paths */
const DECOUPE_BASE      = `public`;
const DECOUPE_IMAGES    = `${DECOUPE_BASE}/images`;
const DECOUPE_FONTS     = `${DECOUPE_BASE}/fonts`;
const DECOUPE_JS        = `${DECOUPE_BASE}/javascript`;
const DECOUPE_STYLES    = `${DECOUPE_BASE}/stylesheets`;
const DECOUPE_PDF       = `${DECOUPE_BASE}/pdf`;

/* CMS related paths */
const CMS_BASE_PATH     = `../site`;
const CMS_THEME_PATH    = `${CMS_BASE_PATH}/wp-content/themes/[THEME_NAME]/`; // Wordpress
// const CMS_THEME_PATH    = `${CMS_BASE_PATH}/sites/all/themes/[THEME_NAME]/`; // Drupal
// const CMS_THEME_PATH    = `${CMS_BASE_PATH}/www/src/[THEME_NAME]/SiteBundle/Ressources/public/`; // eZ


/* Destinations related path */
const STYLES            = `${DECOUPE_BASE}/stylesheets`;
const JAVASCRIPT        = `${DECOUPE_BASE}/javascript`;
const IMAGES            = `${DECOUPE_BASE}/images`;
const FONTS             = `${DECOUPE_BASE}/fonts`;
const PDF               = `${DECOUPE_BASE}/pdf`;


// Exports
exports.DECOUPE_BASE    = DECOUPE_BASE;
exports.DECOUPE_IMAGES  = DECOUPE_IMAGES;
exports.DECOUPE_FONTS   = DECOUPE_FONTS;
exports.DECOUPE_JS      = DECOUPE_JS;
exports.DECOUPE_STYLES  = DECOUPE_STYLES;
exports.DECOUPE_PDF     = DECOUPE_PDF;
exports.CMS_BASE_PATH   = CMS_BASE_PATH;
exports.CMS_THEME_PATH  = CMS_THEME_PATH;
exports.STYLES          = STYLES;
exports.JAVASCRIPT      = JAVASCRIPT;
exports.IMAGES          = IMAGES;
exports.FONTS           = FONTS;
exports.PDF             = PDF;
