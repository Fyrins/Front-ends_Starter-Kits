# HOW TO

Les sources se trouvent dans le dossier `source` ;-)

Tous les fichiers générés se trouvent dans le dossier `public` (Y compris les HTML).

## Quick start

### Install

- Installer nodejs
- Se placer dans le répertoire de travail au niveau du fichier package.json
- On installe ensuite le module gulp ligne de commande en mode global et ensuite le projet :

```shell
npm install -g gulp-cli
npm install
```

npm install est un alias qui lance les commandes 

```shell
npm install && npm update && npm outdated && gulp build-all && gulp watch
```

Ce qui va faire, dans l'ordre :
- Installer les modules listés dans le `package.json`
- Mettre à jour les packages (mises à jour vers les versions mineures)
- Lister les mises à jour possibles (dont les versions majeures)
- Lancer la compilation de toutes les sources
- Lancer un `watch` sur les sources du projet

### Build

Pour générer tous les fichiers d'un seul coup, utiliser la commande :

```shell
gulp build-all
```

Cela build toutes les sources (JS, fonts, CSS, images, HTML)
- les JS sont concaténés et minifiés
- les SASS sont compilés, adaptés en fonction des navigateurs spécifiés dans le fichier build-js.js et minifiés.
- les images sont optimisées

### Watch

Pour éviter d'avoir à build-all à chaque modif, on vérifie les modifications sur les fichiers et on génére les fichiers 
correspondants à la volée

```shell
gulp watch
```

Regarde les modifications sur les HTML, icônes, SASS, images et JS

### Theme

Pour copier les fichiers dans le thème du CMS (hormis les .html), utiliser la commande

```shell
gulp build-theme
```

/*\ Attention /*\ Il faut configurer le chemin vers le thème dans le fichier `paths-dst.js` à la ligne 23

## Requirement

- node >=7.0.0
- npm  >=4.0.3


# BONNES PRATIQUES DEV FRONT

## FR

### Requis
- Dernière version de Bootstrap SASS

### Bootstrap
- Ne jamais utiliser de styles ou de classes directement sur les `row` ou `col` Bootstrap.
- Tous les blocs ou composants doivent se situer DANS les `col`.
- Les `col` doivent toujours être dans des `row`.

Exemple :

```html
<div class="row">
    <div class="col-md-3">
        <div class="sidebar"></div>
    </div>
    <div class="col-md-9">
        <div class="main"></div>
    </div>
</div>
```

### SASS
- Utiliser les plus possible les variables SASS natives de Bootstrap situées dans `_bootstrap-variables.scss`
- Si les variables SASS natives de Bootstrap ont besoin d'être modifier, les dupliquer et les repporter dans _variables.scss
- Éviter les `@extend`
- Nommer les variables pour les couleurs en utilisant http://chir.ag/projects/name-that-color/

### Liens
- Toujours avoir un attribut `title`
- Mettre les attributs dans cet ordre (Prérequis SEO) :

```html
<a href="" title="" class=""></a>
```

### Images
- Toujours avoir un attribut `alt`, même vide
- Utiliser des SVG à la place des PNG pour IE9+
- Pour les icônes, utiliser une police d'icônes

### Police d'icônes
- Mettre les images en SVG dans le dossier svgicons, et la police sera automatiquement générée par GULP dans le dossier public/fonts

### Divers
- Ne pas commit le dossier `node_modules` (i.e. le mettre en mode svn ignore recursif)
- Ne pas utiliser les balises dans le CSS, comme par exemple :

```css
p.class { };
.class { }; /* est suffisant */
```

- HTML5 valide : https://validator.w3.org
- Addresses encodées avec microdata https://developers.google.com/structured-data/schema-org
- Un seul `h1` par page
- Utiliser les classes spéciales IE sur la balise `<html>` pour cibler les versions d'IE

par exemple :

```css
~ .lt-ie9 .sidebar {} /*Pour IE8 ou inférieur*/
```

- Ne jamais utiliser `!important`
- Pour les éléments décoratifs, utiliser les plus possibles du CSS3 à la place des images (exemple : triangles http://apps.eky.hk/css-triangle-generator/)


