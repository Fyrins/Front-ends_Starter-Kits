/* eslint-env node, es6 */
'use strict';

require('./gulp/tasks/build-clean.js');
require('./gulp/tasks/browser-sync.js');
require('./gulp/tasks/build-fonts.js');
require('./gulp/tasks/build-html.js');
require('./gulp/tasks/build-pdf.js');
require('./gulp/tasks/build-icons.js');
require('./gulp/tasks/build-images.js');
require('./gulp/tasks/build-jquery.js');
require('./gulp/tasks/build-iframe.js');
require('./gulp/tasks/build-js.js');
//Build JSPM requires some initialization before it works
//require('./gulp/tasks/build-jspm.js');
require('./gulp/tasks/build-modernizr.js');
require('./gulp/tasks/build-scss.js');

require('./gulp/tasks/build-theme.js');
require('./gulp/tasks/build-all.js');
require('./gulp/tasks/default.js');
require('./gulp/tasks/watch.js');
